========================================================================
THÔNG SỐ KỸ THUẬT GIA CÔNG MẠCH IN (PCB) VÀ HÀN LINH KIỆN (PCBA)
DỰ ÁN: NODE ALL SENSORS - THIẾT KẾ TRÊN ALTIUM DESIGNER 26
========================================================================

1. YÊU CẦU GIA CÔNG BO MẠCH IN TRẦN (BARE PCB SPECIFICATIONS):
   - Kích thước mạch (Dimensions): 138.10 mm x 88.93 mm (5437 mil x 3501 mil).
   - Số lớp đồng (Layer Count): 02 lớp (Top Layer & Bottom Layer).
   - Độ dày bo mạch (PCB Thickness): 1.6 mm.
   - Vật liệu (Base Material): FR-4 Standard TG130-140.
   - Độ dày đồng (Copper Weight): 1 oz (35 um).
   - Màu phủ hàn (Solder Mask Color): Green (Xanh lá truyền thống).
   - Màu in chữ (Silkscreen Color): White (Trắng).
   - Mạ bề mặt pad hàn (Surface Finish): HASL with lead hoặc HASL Lead-Free (Mạ thiếc hàn).
   - Cắt mạch (Board Outline): Cắt viền chữ nhật theo Mechanical 1 (GM1) / Keep-Out (GKO).
   - ĐẶC BIỆT LƯU Ý VÙNG ANTEN ESP32: Khu vực Anten hình chữ nhật ở mép trên bo mạch (đã khoét đồng Polygon Cutout cả 2 mặt Top và Bottom) giữ nguyên phíp trần FR4, KHÔNG phủ đồng và KHÔNG phay/khoét thủng lỗ qua phíp.

2. YÊU CẦU LẮP RÁP VÀ HÀN LINH KIỆN (PCBA / ASSEMBLY SPECIFICATIONS):
   - Công nghệ hàn: Toàn bộ là linh kiện chân cắm THT (Through-Hole Technology).
   - Danh mục linh kiện nhập chuẩn theo thư mục: 02_BOM (file Excel hoặc CSV).
   - Tọa độ và trạng thái hàn chuẩn theo thư mục: 03_Pick_and_Place_CPL.

3. QUY ĐỊNH QUAN TRỌNG VỀ VỊ TRÍ U2 (ESP32) VÀ CÁC CỔNG CẢM BIẾN / MODULE:
   ---------------------------------------------------------------------
   [!] KHÁCH HÀNG ĐÃ CÓ SẴN MODULE ESP32 VÀ CÁC MODULE CẢM BIẾN Ở NHÀ.
       XƯỞNG KHÔNG MUA MODULE ESP32 VÀ KHÔNG MUA CÁC MODULE CẢM BIẾN,
       MÀ CHỈ MUA VÀ HÀN ĐẾ RÀO (HEADER 2.54mm) THEO ĐÚNG FILE BOM & CPL:
   ---------------------------------------------------------------------
   - Vị trí U2 (ESP32-S3): Hàn 02 thanh ĐẾ RÀO CÁI (Female Header 1x22P Pitch 2.54mm).
   - Vị trí J_OLED, J_SHT30, J_BH1750, J_SCD40, MOD_UPS_5V: Hàn ĐẾ RÀO CÁI (Female Header 1x4P Pitch 2.54mm).
   - Vị trí J_MIC: Hàn ĐẾ RÀO CÁI (Female Header 1x6P Pitch 2.54mm).
   - Vị trí J_SPK: Hàn ĐẾ RÀO CÁI (Female Header 1x5P Pitch 2.54mm).
   - Vị trí J_DUST: Hàn RÀO ĐỰC (Male Pin Header 1x6P Pitch 2.54mm) hoặc đế XH2.54-6P.
   - Vị trí J_BAT: Hàn RÀO ĐỰC (Male Pin Header 1x2P Pitch 2.54mm) hoặc đế XH2.54-2P.
   - Các linh kiện rời còn lại (U1, C1..C5, C_VLED, Cf, R1..R9, R_B, R_VLED, Q_DUST, D_DC, D_BAT, F1, JACK1, D1, G_LED, B_LED, R_LED): Nhập và hàn đầy đủ theo đúng BOM và Pick & Place.

========================================================================
